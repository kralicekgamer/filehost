from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from readJson import getJson


app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///votes.db' 
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False  


db = SQLAlchemy(app)
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        

class Vote(db.Model):
    id = db.Column(db.Integer, primary_key=True)  
    meal_type = db.Column(db.String(50), nullable=False) 
    meal_name = db.Column(db.String(200), nullable=False) 
    rating = db.Column(db.Integer, nullable=False)  

    def __repr__(self):
        return f'<Vote {self.meal_type} {self.meal_name} {self.rating}>'


@app.route("/")
def index():
    jidelnicek = getJson()  
    meals_with_ratings = []

    for meal_type in ['breakfast', 'lunch', 'dinner']:
        meals = jidelnicek.get(meal_type, [])
        if not isinstance(meals, list):
            meals = [meals]  

        for meal in meals:
            votes = Vote.query.filter_by(meal_type=meal_type, meal_name=meal).all()
            average_rating = sum(vote.rating for vote in votes) / len(votes) if votes else 0
            meals_with_ratings.append({
                'type': meal_type,
                'name': meal,
                'average_rating': round(average_rating, 1)
            })

    return render_template("index.html", jidelnicek=jidelnicek, meals_with_ratings=meals_with_ratings)

@app.route("/vote", methods=["POST"])
def vote():
    meal_type = request.form.get("meal_type")
    meal_name = request.form.get("meal_name")
    rating = int(request.form.get("rating"))
    new_vote = Vote(meal_type=meal_type, meal_name=meal_name, rating=rating)
    db.session.add(new_vote)
    db.session.commit()

    return redirect(url_for("index"))

if __name__ == "__main__":
    with app.app_context():
        db.create_all() 
    app.run(debug=False)