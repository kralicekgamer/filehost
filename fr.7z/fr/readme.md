Pro instalaci závislostí "pip install -r requirements.txt"
Pro spuštění programu main.py

Funguje pouze na windowsu!
Oteři v prohlížeči na: http://127.0.0.1:5000