def custom_encrypt(text, password):
    encrypted = []
    for i, char in enumerate(text):
        key_char = password[i % len(password)]
        # Kombinace XOR + posun o index znaku
        encrypted_char = chr((ord(char) ^ ord(key_char) + i) % 256)
        encrypted.append(encrypted_char)
    return ''.join(encrypted)

def custom_decrypt(encrypted_text, password):
    decrypted = []
    for i, char in enumerate(encrypted_text):
        key_char = password[i % len(password)]
        # Inverzní operace k encrypt
        decrypted_char = chr(((ord(char) - i) ^ ord(key_char)) % 256)
        decrypted.append(decrypted_char)
    return ''.join(decrypted)

# --- Příklad použití ---
if __name__ == "__main__":
    mode = input("Zadej mód (encrypt/decrypt): ").strip().lower()
    text = input("Zadej text: ")
    password = input("Zadej heslo: ")

    if mode == "encrypt":
        encrypted = custom_encrypt(text, password)
        print("Zašifrovaný text:", encrypted.encode("latin1"))  # Pro čitelnost
    elif mode == "decrypt":
        # Pokud jsi encryptoval dříve a uložil jako bajty, použij decode
        decrypted = custom_decrypt(text, password)
        print("Dešifrovaný text:", decrypted)
    else:
        print("Neplatný mód. Použij 'encrypt' nebo 'decrypt'.")
