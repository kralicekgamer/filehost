def encrypt_polyposun(text, key):
    """
    Šifruje text pomocí algoritmu Polyposun.
    :param text: Řetězec, který má být zašifrován.
    :param key: Řetězec (klíč) pro šifrování.
    :return: Zašifrovaný řetězec.
    """
    encrypted_text = []
    key_length = len(key)
    for i, char in enumerate(text):
        # Vezmeme odpovídající znak z klíče (opakujeme klíč, pokud je kratší než text)
        key_char = key[i % key_length]
        
        # Určíme posun na základě ASCII hodnoty znaku z klíče
        shift = ord(key_char)
        
        # Zašifrujeme znak: posuneme jeho ASCII hodnotu
        encrypted_char_val = (ord(char) + shift) % 256  # Používáme modulo 256 pro ASCII rozsah
        encrypted_text.append(chr(encrypted_char_val))
        
    return "".join(encrypted_text)

def decrypt_polyposun(encrypted_text, key):
    """
    Dešifruje text zašifrovaný algoritmem Polyposun.
    :param encrypted_text: Řetězec, který má být dešifrován.
    :param key: Řetězec (klíč) pro dešifrování. Musí být stejný jako při šifrování.
    :return: Dešifrovaný (původní) řetězec.
    """
    decrypted_text = []
    key_length = len(key)
    for i, char in enumerate(encrypted_text):
        key_char = key[i % key_length]
        shift = ord(key_char)
        
        # Dešifrujeme znak: vrátíme posun zpět
        # Pro dešifrování potřebujeme zajistit, aby výsledek (ord(char) - shift) byl vždy kladný
        # než použijeme modulo.
        decrypted_char_val = (ord(char) - shift + 256) % 256
        decrypted_text.append(chr(decrypted_char_val))
        
    return "".join(decrypted_text)

def main():
    while True:
        print("\n--- Polyposun Šifrování/Dešifrování ---")
        print("1. Zašifrovat text")
        print("2. Odšifrovat text")
        print("3. Konec")
        
        choice = input("Zadejte volbu (1/2/3): ")
        
        if choice == '1':
            text = input("Zadejte text k zašifrování: ")
            key = input("Zadejte klíč (heslo) pro šifrování: ")
            
            if not key:
                print("Klíč nesmí být prázdný!")
                continue
                
            encrypted = encrypt_polyposun(text, key)
            print(f"Zašifrovaný text: {encrypted}")
            
        elif choice == '2':
            encrypted_text = input("Zadejte zašifrovaný text: ")
            key = input("Zadejte klíč (heslo) pro odšifrování: ")
            
            if not key:
                print("Klíč nesmí být prázdný!")
                continue
                
            decrypted = decrypt_polyposun(encrypted_text, key)
            print(f"Odšifrovaný text: {decrypted}")
            
        elif choice == '3':
            print("Děkuji za použití algoritmu Polyposun! Na shledanou.")
            break
            
        else:
            print("Neplatná volba. Zkuste to prosím znovu.")

if __name__ == "__main__":
    main()