import random
import base64

class VlastniSifra:
    def __init__(self, heslo: str):
        """
        Inicializace šifry s heslem
        """
        self.heslo = heslo
        self.klic = self._vygeneruj_klic(heslo)
    
    def _vygeneruj_klic(self, heslo: str) -> list:
        """
        Generuje šifrovací klíč z hesla pomocí hash funkce
        """
        hash_val = 0
        for char in heslo:
            hash_val = (hash_val * 31 + ord(char)) % 1000000
        
        # Vytvoří deterministický klíč z hashe
        random.seed(hash_val)
        klic = list(range(256))
        random.shuffle(klic)
        return klic
    
    def _substituce(self, text: str, smer: str) -> str:
        """
        Substituce znaků podle klíče
        """
        vysledek = ""
        
        if smer == "sifruj":
            for char in text:
                ascii_val = ord(char)
                novy_val = self.klic[ascii_val % 256]
                vysledek += chr(novy_val % 256)
        else:  # desifruj
            # Vytvoří reverzní klíč
            rev_klic = [0] * 256
            for i, val in enumerate(self.klic):
                rev_klic[val % 256] = i
            
            for char in text:
                ascii_val = ord(char)
                puvodni_val = rev_klic[ascii_val]
                vysledek += chr(puvodni_val)
        
        return vysledek
    
    def _transpozice(self, text: str, smer: str) -> str:
        """
        Transpozice - přeskupení znaků v blocích
        """
        delka_bloku = len(self.heslo) + 3  # Velikost bloku závisí na hesle
        
        if smer == "sifruj":
            vysledek = ""
            for i in range(0, len(text), delka_bloku):
                blok = text[i:i + delka_bloku]
                # Obrátí blok a posune znaky
                obraceny = blok[::-1]
                vysledek += obraceny
            return vysledek
        else:  # desifruj
            vysledek = ""
            for i in range(0, len(text), delka_bloku):
                blok = text[i:i + delka_bloku]
                # Obrátí zpět
                obraceny = blok[::-1]
                vysledek += obraceny
            return vysledek
    
    def _xor_operace(self, text: str) -> str:
        """
        XOR operace s heslem
        """
        vysledek = ""
        for i, char in enumerate(text):
            heslo_char = self.heslo[i % len(self.heslo)]
            xor_result = ord(char) ^ ord(heslo_char)
            vysledek += chr(xor_result % 256)
        return vysledek
    
    def sifruj(self, text: str) -> str:
        """
        Zašifruje text pomocí kombinace technik
        """
        # 1. XOR s heslem
        krok1 = self._xor_operace(text)
        
        # 2. Substituce
        krok2 = self._substituce(krok1, "sifruj")
        
        # 3. Transpozice
        krok3 = self._transpozice(krok2, "sifruj")
        
        # 4. Další XOR pro větší bezpečnost
        krok4 = self._xor_operace(krok3)
        
        # 5. Base64 encoding pro čitelný výstup
        zasifrovano = base64.b64encode(krok4.encode('latin1')).decode('ascii')
        
        return zasifrovano
    
    def desifruj(self, zasifrovany_text: str) -> str:
        """
        Dešifruje text (opačný postup)
        """
        try:
            # 1. Base64 decoding
            krok1 = base64.b64decode(zasifrovany_text.encode('ascii')).decode('latin1')
            
            # 2. XOR (je symetrický)
            krok2 = self._xor_operace(krok1)
            
            # 3. Transpozice zpět
            krok3 = self._transpozice(krok2, "desifruj")
            
            # 4. Substituce zpět
            krok4 = self._substituce(krok3, "desifruj")
            
            # 5. Finální XOR
            desifrovano = self._xor_operace(krok4)
            
            return desifrovano
            
        except Exception as e:
            return f"Chyba při dešifrování: {str(e)}"


def main():
    """
    Hlavní funkce pro testování
    """
    print("=== VLASTNÍ ŠIFROVACÍ ALGORITMUS ===")
    print()
    
    while True:
        print("1. Zašifrovat text")
        print("2. Dešifrovat text")
        print("3. Demo")
        print("4. Ukončit")
        
        volba = input("\nZvolte akci (1-4): ").strip()
        
        if volba == "1":
            heslo = input("Zadejte heslo: ")
            text = input("Zadejte text k zašifrování: ")
            
            sifra = VlastniSifra(heslo)
            zasifrovany = sifra.sifruj(text)
            
            print(f"\nZašifrovaný text:")
            print(zasifrovany)
            print()
            
        elif volba == "2":
            heslo = input("Zadejte heslo: ")
            zasifrovany_text = input("Zadejte zašifrovaný text: ")
            
            sifra = VlastniSifra(heslo)
            desifrovany = sifra.desifruj(zasifrovany_text)
            
            print(f"\nDešifrovaný text:")
            print(desifrovany)
            print()
            
        elif volba == "3":
            print("\n=== DEMO ===")
            heslo = "mojetajneheslo123"
            puvodni_text = "Toto je tajná zpráva! 🔐"
            
            print(f"Původní text: {puvodni_text}")
            print(f"Heslo: {heslo}")
            
            sifra = VlastniSifra(heslo)
            zasifrovany = sifra.sifruj(puvodni_text)
            print(f"Zašifrovaný: {zasifrovany}")
            
            desifrovany = sifra.desifruj(zasifrovany)
            print(f"Dešifrovaný: {desifrovany}")
            
            print(f"Úspěšné dešifrování: {'✓' if desifrovany == puvodni_text else '✗'}")
            print()
            
        elif volba == "4":
            print("Nashledanou!")
            break
            
        else:
            print("Neplatná volba!")


if __name__ == "__main__":
    main()