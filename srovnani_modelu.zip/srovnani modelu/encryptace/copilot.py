def encrypt(text, key):
    encrypted_text = ""
    for char in text:
        if char.isalpha():
            shift = key % 26
            new_char = chr(((ord(char.lower()) - ord('a') + shift) % 26) + ord('a'))
            encrypted_text += new_char.upper() if char.isupper() else new_char
        else:
            encrypted_text += char
    return encrypted_text

def decrypt(encrypted_text, key):
    return encrypt(encrypted_text, -key)  # Opačný posun znaků

# Použití
key = 5  # Nastavení klíče pro posun
message = "Hello, World!"
encrypted_message = encrypt(message, key)
decrypted_message = decrypt(encrypted_message, key)

print(f"Šifrovaný text: {encrypted_message}")
print(f"Dešifrovaný text: {decrypted_message}")
