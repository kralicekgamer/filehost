def encrypt(text, password):
    encrypted = []
    pwd_len = len(password)
    for i, char in enumerate(text):
        key_char = password[i % pwd_len]
        # Posun podle Unicode hodnoty znaku hesla + indexu
        shift = (ord(key_char) + i) % 256
        encrypted_char = chr((ord(char) + shift) % 256)
        encrypted.append(encrypted_char)
    return ''.join(encrypted)

def decrypt(encrypted_text, password):
    decrypted = []
    pwd_len = len(password)
    for i, char in enumerate(encrypted_text):
        key_char = password[i % pwd_len]
        shift = (ord(key_char) + i) % 256
        decrypted_char = chr((ord(char) - shift) % 256)
        decrypted.append(decrypted_char)
    return ''.join(decrypted)

if __name__ == "__main__":
    mode = input("Zadej mód (encrypt/decrypt): ").strip().lower()
    text = input("Zadej text: ")
    password = input("Zadej heslo: ")

    if mode == "encrypt":
        result = encrypt(text, password)
        print("Zašifrovaný text:", result)
    elif mode == "decrypt":
        result = decrypt(text, password)
        print("Dešifrovaný text:", result)
    else:
        print("Neplatný mód. Použij 'encrypt' nebo 'decrypt'.")