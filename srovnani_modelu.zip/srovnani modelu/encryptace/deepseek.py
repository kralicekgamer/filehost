class ShiftXorCipher:
    def __init__(self, key):
        self.key = key
    
    def encrypt(self, text):
        encrypted = []
        for char in text:
            # Posun ASCII hodnoty
            shifted = ord(char) + self.key
            # XOR operace
            xor = shifted ^ self.key
            encrypted.append(chr(xor))
        return ''.join(encrypted)
    
    def decrypt(self, encrypted_text):
        decrypted = []
        for char in encrypted_text:
            # Zpětná XOR operace
            xor = ord(char) ^ self.key
            # Zpětný posun ASCII hodnoty
            shifted = xor - self.key
            decrypted.append(chr(shifted))
        return ''.join(decrypted)


# Ukázka použití
if __name__ == "__main__":
    cipher = ShiftXorCipher(key=42)  # Klíč může být libovolné celé číslo
    
    while True:
        print("\n1. Zašifrovat text")
        print("2. Dešifrovat text")
        print("3. Konec")
        choice = input("Vyberte možnost: ")
        
        if choice == "1":
            text = input("Zadejte text k zašifrování: ")
            encrypted = cipher.encrypt(text)
            print(f"Zašifrovaný text: {encrypted}")
        elif choice == "2":
            text = input("Zadejte text k dešifrování: ")
            decrypted = cipher.decrypt(text)
            print(f"Dešifrovaný text: {decrypted}")
        elif choice == "3":
            break
        else:
            print("Neplatná volba, zkuste znovu.")