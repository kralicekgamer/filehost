def create_cipher(key):
    alphabet = 'abcdefghijklmnopqrstuvwxyz'
    cipher = {}
    
    for i, char in enumerate(alphabet):
        cipher[char] = key[i]
    
    return cipher

def encrypt(text, key):
    cipher = create_cipher(key)
    encrypted_text = ''
    
    for char in text:
        if char in cipher:
            encrypted_text += cipher[char]
        else:
            encrypted_text += char  # Non-alphabet characters remain unchanged
    
    return encrypted_text

def decrypt(encrypted_text, key):
    alphabet = 'abcdefghijklmnopqrstuvwxyz'
    reverse_cipher = {v: k for k, v in create_cipher(key).items()}
    decrypted_text = ''
    
    for char in encrypted_text:
        if char in reverse_cipher:
            decrypted_text += reverse_cipher[char]
        else:
            decrypted_text += char  # Non-alphabet characters remain unchanged
    
    return decrypted_text

# Příklad použití
key = 'zyxwvutsrqponmlkjihgfedcba'  # Klíč pro šifrování (obrácená abeceda)
text = 'hello world'

encrypted = encrypt(text, key)
print(f'Encrypted: {encrypted}')

decrypted = decrypt(encrypted, key)
print(f'Decrypted: {decrypted}')
