import pygame
import random
import sys

# Inicializace
pygame.init()

# Nastavení obrazovky
WIDTH, HEIGHT = 640, 480
TILE_SIZE = 20
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Pacman v Pythonu")

# Barvy
BLACK = (0, 0, 0)
YELLOW = (255, 255, 0)
BLUE = (0, 0, 255)
WHITE = (255, 255, 255)

# Herní mapa (1 = zeď, 0 = cesta, . = jídlo)
MAP = [
    "11111111111111111111",
    "1........11........1",
    "1.111.11111.111.1111",
    "1.1..............1.1",
    "1.1.111.1111.111.1.1",
    "1....1..1..1..1....1",
    "1111.1.1.11.1.1.1111",
    "1........P.........1",
    "11111111111111111111"
]

ROWS = len(MAP)
COLS = len(MAP[0])

# Konverze mapy na seznam
world = []
dots = []

for row_idx, row in enumerate(MAP):
    world_row = []
    for col_idx, cell in enumerate(row):
        if cell == '1':
            world_row.append(1)
        else:
            world_row.append(0)
            if cell == '.' or cell == 'P':
                dots.append((col_idx, row_idx))
    world.append(world_row)

# Najdi počáteční pozici Pacmana
for y, row in enumerate(MAP):
    for x, cell in enumerate(row):
        if cell == 'P':
            pacman_x, pacman_y = x, y

clock = pygame.time.Clock()
score = 0

def draw_world():
    screen.fill(BLACK)
    for y in range(ROWS):
        for x in range(COLS):
            if world[y][x] == 1:
                pygame.draw.rect(screen, BLUE, (x*TILE_SIZE, y*TILE_SIZE, TILE_SIZE, TILE_SIZE))
            elif (x, y) in dots:
                pygame.draw.circle(screen, WHITE, (x*TILE_SIZE + TILE_SIZE//2, y*TILE_SIZE + TILE_SIZE//2), 3)

def draw_pacman(x, y):
    pygame.draw.circle(screen, YELLOW, (x*TILE_SIZE + TILE_SIZE//2, y*TILE_SIZE + TILE_SIZE//2), TILE_SIZE//2 - 2)

# Hlavní smyčka
direction = (0, 0)
running = True

while running:
    clock.tick(10)  # FPS

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                direction = (-1, 0)
            elif event.key == pygame.K_RIGHT:
                direction = (1, 0)
            elif event.key == pygame.K_UP:
                direction = (0, -1)
            elif event.key == pygame.K_DOWN:
                direction = (0, 1)

    # Pohyb
    next_x = pacman_x + direction[0]
    next_y = pacman_y + direction[1]
    if world[next_y][next_x] == 0:
        pacman_x, pacman_y = next_x, next_y

    # Jídlo
    if (pacman_x, pacman_y) in dots:
        dots.remove((pacman_x, pacman_y))
        score += 10

    draw_world()
    draw_pacman(pacman_x, pacman_y)

    # Skóre
    font = pygame.font.SysFont(None, 24)
    score_text = font.render(f"Skóre: {score}", True, WHITE)
    screen.blit(score_text, (10, HEIGHT - 30))

    pygame.display.flip()

pygame.quit()
sys.exit()
