import pygame
import sys
import math

pygame.init()
clock = pygame.time.Clock()

WIDTH, HEIGHT = 480, 480
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Minimalist Pacman")

BLACK = (0, 0, 0)
YELLOW = (255, 255, 0)
WHITE = (255, 255, 255)
BLUE = (0, 0, 150)
RED = (255, 0, 0)
PINK = (255, 182, 193)
CYAN = (0, 255, 255)
ORANGE = (255, 165, 0)

TILE_SIZE = 24
ROWS = 19
COLS = 20

UP = (0, -1)
DOWN = (0, 1)
LEFT = (-1, 0)
RIGHT = (1, 0)

maze = [
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    [1,3,0,0,0,1,0,0,0,1,1,0,0,0,1,0,0,0,3,1],
    [1,0,1,1,0,1,0,1,0,0,0,0,1,0,1,0,1,1,0,1],
    [1,0,1,1,0,1,0,1,1,1,1,1,1,0,1,0,1,1,0,1],
    [1,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,1],
    [1,0,1,1,0,1,1,1,0,0,0,0,1,1,1,0,1,1,0,1],
    [1,0,0,0,0,1,0,0,0,1,1,0,0,0,1,0,0,0,0,1],
    [1,1,1,1,0,1,0,1,1,1,1,1,1,0,1,0,1,1,1,1],
    [1,1,1,1,0,0,0,0,0,1,1,0,0,0,1,0,1,1,1,1],
    [1,1,1,1,1,1,1,1,0,0,0,0,1,1,1,1,1,1,1,1],
    [1,1,1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,1,1,1],
    [1,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,1],
    [1,0,1,1,0,1,1,1,0,0,0,0,1,1,1,0,1,1,0,1],
    [1,0,0,1,0,0,0,1,1,1,1,1,1,0,0,0,1,0,0,1],
    [1,1,0,1,0,1,0,0,0,1,1,0,0,0,1,0,1,0,1,1],
    [1,0,0,0,0,1,1,1,0,1,1,0,1,1,1,0,0,0,0,1],
    [1,0,1,1,0,1,0,0,0,0,0,0,0,0,1,0,1,1,0,1],
    [1,3,0,0,0,0,0,1,1,1,1,1,1,0,0,0,0,0,3,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
]

pellet_count = sum(row.count(2) + row.count(3) for row in maze)

class Player:
    def __init__(self):
        # position in col,row: x,y but maze[row][col]
        self.col = 1
        self.row = 1
        self.dir = LEFT
        self.next_dir = LEFT
        self.radius = TILE_SIZE // 2 - 2
        self.mouth_opening = 0
        self.mouth_opening_max = 22
        self.mouth_opening_speed = 4
        self.mouth_opening_dir = 1
        self.power_mode = False
        self.power_mode_timer = 0

    def update(self):
        if self.can_move(self.next_dir):
            self.dir = self.next_dir
        if self.can_move(self.dir):
            self.col += self.dir[0]
            self.row += self.dir[1]

        self.mouth_opening += self.mouth_opening_dir * self.mouth_opening_speed
        if self.mouth_opening >= self.mouth_opening_max or self.mouth_opening <= 0:
            self.mouth_opening_dir *= -1
            self.mouth_opening = max(0, min(self.mouth_opening, self.mouth_opening_max))

        if self.power_mode:
            self.power_mode_timer -= 1
            if self.power_mode_timer <= 0:
                self.power_mode = False

    def can_move(self, direction):
        new_col = self.col + direction[0]
        new_row = self.row + direction[1]
        if 0 <= new_row < ROWS and 0 <= new_col < COLS:
            return maze[new_row][new_col] != 1
        return False

    def draw(self, surface):
        x = self.col * TILE_SIZE + TILE_SIZE // 2
        y = self.row * TILE_SIZE + TILE_SIZE // 2
        mouth_angle = math.radians(self.mouth_opening)

        if self.dir == LEFT:
            start_angle = math.pi + mouth_angle
            end_angle = 2 * math.pi - mouth_angle
        elif self.dir == RIGHT:
            start_angle = mouth_angle
            end_angle = 2 * math.pi - mouth_angle
        elif self.dir == UP:
            start_angle = 1.5 * math.pi + mouth_angle
            end_angle = start_angle + (2 * math.pi - mouth_angle * 2)
        elif self.dir == DOWN:
            start_angle = 0.5 * math.pi + mouth_angle
            end_angle = start_angle + (2 * math.pi - mouth_angle * 2)
        else:
            start_angle = mouth_angle
            end_angle = 2 * math.pi - mouth_angle

        pygame.draw.circle(surface, YELLOW, (x, y), self.radius)
        mouth_pos1 = (x, y)
        mouth_pos2 = (x + self.radius * math.cos(start_angle), y - self.radius * math.sin(start_angle))
        mouth_pos3 = (x + self.radius * math.cos(end_angle), y - self.radius * math.sin(end_angle))
        pygame.draw.polygon(surface, BLACK, [mouth_pos1, mouth_pos2, mouth_pos3])

class Ghost:
    def __init__(self, row, col, color, scatter_target):
        self.row = row
        self.col = col
        self.color = color
        self.scatter_target = scatter_target
        self.radius = TILE_SIZE // 2 - 2
        self.dir = LEFT
        self.speed_counter = 0
        self.speed_limit = 6

    def update(self):
        self.speed_counter += 1
        if self.speed_counter < self.speed_limit:
            return
        self.speed_counter = 0

        possible_dirs = [UP, DOWN, LEFT, RIGHT]
        best_dir = None
        best_dist = float('inf')

        for direction in possible_dirs:
            new_col = self.col + direction[0]
            new_row = self.row + direction[1]
            if 0 <= new_row < ROWS and 0 <= new_col < COLS:
                if maze[new_row][new_col] != 1:
                    dist = math.hypot(player.col - new_col, player.row - new_row)
                    if dist < best_dist:
                        best_dist = dist
                        best_dir = direction
        if best_dir:
            self.col += best_dir[0]
            self.row += best_dir[1]
            self.dir = best_dir

    def draw(self, surface):
        x = self.col * TILE_SIZE + TILE_SIZE // 2
        y = self.row * TILE_SIZE + TILE_SIZE // 2

        body_rect = pygame.Rect(x - self.radius, y - self.radius, self.radius * 2, self.radius * 2)
        pygame.draw.circle(surface, self.color, (x, y), self.radius)
        pygame.draw.rect(surface, self.color, [x - self.radius, y, 2 * self.radius, self.radius])

        zigzag_height = 5
        zigzag_width = 2 * self.radius / 6
        points = []
        for i in range(7):
            x_pos = x - self.radius + i * zigzag_width
            y_pos = y + self.radius if i % 2 == 0 else y + self.radius - zigzag_height
            points.append((x_pos, y_pos))
        pygame.draw.polygon(surface, BLACK, points)

        eye_radius = self.radius // 3
        eye_x_offset = self.radius // 2
        eye_y_offset = self.radius // 3
        eye_center_left = (x - eye_x_offset, y - eye_y_offset)
        eye_center_right = (x + eye_x_offset, y - eye_y_offset)
        pygame.draw.circle(surface, WHITE, eye_center_left, eye_radius)
        pygame.draw.circle(surface, WHITE, eye_center_right, eye_radius)

        dir_x = player.col - self.col
        dir_y = player.row - self.row
        length = math.hypot(dir_x, dir_y)
        if length == 0:
            length = 1
        dir_x /= length
        dir_y /= length
        pupil_offset = eye_radius // 2
        pupil_pos_left = (eye_center_left[0] + dir_x * pupil_offset, eye_center_left[1] + dir_y * pupil_offset)
        pupil_pos_right = (eye_center_right[0] + dir_x * pupil_offset, eye_center_right[1] + dir_y * pupil_offset)
        pygame.draw.circle(surface, BLACK, (int(pupil_pos_left[0]), int(pupil_pos_left[1])), eye_radius // 2)
        pygame.draw.circle(surface, BLACK, (int(pupil_pos_right[0]), int(pupil_pos_right[1])), eye_radius // 2)

player = Player()
ghosts = [
    Ghost(9, 9, RED, (0, 0)),
    Ghost(9, 10, PINK, (COLS-1, 0)),
    Ghost(10, 9, CYAN, (0, ROWS-1)),
    Ghost(10, 10, ORANGE, (COLS-1, ROWS-1))
]

score = 0
font = pygame.font.SysFont("arial", 24)

def draw_maze(surface):
    for r in range(ROWS):
        for c in range(COLS):
            x = c * TILE_SIZE
            y = r * TILE_SIZE
            if maze[r][c] == 1:
                pygame.draw.rect(surface, BLUE, (x, y, TILE_SIZE, TILE_SIZE))
            elif maze[r][c] == 2:
                pygame.draw.circle(surface, WHITE, (x + TILE_SIZE//2, y + TILE_SIZE//2), 4)
            elif maze[r][c] == 3:
                pygame.draw.circle(surface, WHITE, (x + TILE_SIZE//2, y + TILE_SIZE//2), 8)

def check_pellet_collision():
    global score, pellet_count
    if 0 <= player.row < ROWS and 0 <= player.col < COLS:
        cell = maze[player.row][player.col]
        if cell == 2:
            score += 10
            pellet_count -= 1
            maze[player.row][player.col] = 0
        elif cell == 3:
            score += 50
            pellet_count -= 1
            maze[player.row][player.col] = 0
            player.power_mode = True
            player.power_mode_timer = 300

def check_ghost_collision():
    for ghost in ghosts:
        if ghost.row == player.row and ghost.col == player.col:
            if player.power_mode:
                ghost.row, ghost.col = 9, 9
                global score
                score += 200
            else:
                return True
    return False

def draw_score(surface):
    score_text = font.render(f"Score: {score}", True, WHITE)
    surface.blit(score_text, (10, HEIGHT - 30))

def main():
    running = True
    while running:
        screen.fill(BLACK)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                break
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    player.next_dir = UP
                elif event.key == pygame.K_DOWN:
                    player.next_dir = DOWN
                elif event.key == pygame.K_LEFT:
                    player.next_dir = LEFT
                elif event.key == pygame.K_RIGHT:
                    player.next_dir = RIGHT

        player.update()
        for ghost in ghosts:
            ghost.update()

        check_pellet_collision()

        if check_ghost_collision():
            reset_game()

        draw_maze(screen)
        player.draw(screen)
        for ghost in ghosts:
            ghost.draw(screen)
        draw_score(screen)

        if pellet_count == 0:
            win_text = font.render("YOU WIN!", True, WHITE)
            screen.blit(win_text, (WIDTH//2 - win_text.get_width()//2, HEIGHT//2 - win_text.get_height()//2))

        pygame.display.flip()
        clock.tick(10)

    pygame.quit()
    sys.exit()

def reset_game():
    global pellet_count, score, maze
    maze[:] = [
        [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
        [1,3,0,0,0,1,0,0,0,1,1,0,0,0,1,0,0,0,3,1],
        [1,0,1,1,0,1,0,1,0,0,0,0,1,0,1,0,1,1,0,1],
        [1,0,1,1,0,1,0,1,1,1,1,1,1,0,1,0,1,1,0,1],
        [1,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,1],
        [1,0,1,1,0,1,1,1,0,0,0,0,1,1,1,0,1,1,0,1],
        [1,0,0,0,0,1,0,0,0,1,1,0,0,0,1,0,0,0,0,1],
        [1,1,1,1,0,1,0,1,1,1,1,1,1,0,1,0,1,1,1,1],
        [1,1,1,1,0,0,0,0,0,1,1,0,0,0,1,0,1,1,1,1],
        [1,1,1,1,1,1,1,1,0,0,0,0,1,1,1,1,1,1,1,1],
        [1,1,1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,1,1,1],
        [1,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,1],
        [1,0,1,1,0,1,1,1,0,0,0,0,1,1,1,0,1,1,0,1],
        [1,0,0,1,0,0,0,1,1,1,1,1,1,0,0,0,1,0,0,1],
        [1,1,0,1,0,1,0,0,0,1,1,0,0,0,1,0,1,0,1,1],
        [1,0,0,0,0,1,1,1,0,1,1,0,1,1,1,0,0,0,0,1],
        [1,0,1,1,0,1,0,0,0,0,0,0,0,0,1,0,1,1,0,1],
        [1,3,0,0,0,0,0,1,1,1,1,1,1,0,0,0,0,0,3,1],
        [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    ]
    pellet_count = sum(row.count(2) + row.count(3) for row in maze)
    player.col, player.row = 1, 1
    player.dir = LEFT
    player.next_dir = LEFT
    player.power_mode = False
    player.power_mode_timer = 0
    for i, ghost in enumerate(ghosts):
        ghost.row, ghost.col = 9 + i//2, 9 + i%2

if __name__ == "__main__":
    main()

