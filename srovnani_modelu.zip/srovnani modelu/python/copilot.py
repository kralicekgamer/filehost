import pygame

# Inicializace pygame
pygame.init()

# Nastavení velikosti okna
WIDTH, HEIGHT = 500, 500
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Pac-Man")

# Barvy
BLACK = (0, 0, 0)
YELLOW = (255, 255, 0)
RED = (255, 0, 0)

# Pac-Man
pacman_radius = 20
pacman_x, pacman_y = WIDTH // 2, HEIGHT // 2
pacman_speed = 5

# Duch (jednoduchý obdélník)
ghost_width, ghost_height = 30, 30
ghost_x, ghost_y = 100, 100

# Hlavní smyčka hry
running = True
while running:
    pygame.time.delay(50)

    # Zpracování událostí
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Pohyb Pac-Mana
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT] and pacman_x - pacman_radius > 0:
        pacman_x -= pacman_speed
    if keys[pygame.K_RIGHT] and pacman_x + pacman_radius < WIDTH:
        pacman_x += pacman_speed
    if keys[pygame.K_UP] and pacman_y - pacman_radius > 0:
        pacman_y -= pacman_speed
    if keys[pygame.K_DOWN] and pacman_y + pacman_radius < HEIGHT:
        pacman_y += pacman_speed

    # Vykreslení
    screen.fill(BLACK)
    pygame.draw.circle(screen, YELLOW, (pacman_x, pacman_y), pacman_radius)
    pygame.draw.rect(screen, RED, (ghost_x, ghost_y, ghost_width, ghost_height))
    
    pygame.display.update()

pygame.quit()
