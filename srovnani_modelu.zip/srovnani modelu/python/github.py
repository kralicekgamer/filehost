import pygame
import random
import sys
import math  # DOPLNENO O SPRÁVNÝ MODUL

# Nastavení velikosti okna a mřížky
CELL_SIZE = 20
GRID_WIDTH = 19
GRID_HEIGHT = 21
WIDTH = CELL_SIZE * GRID_WIDTH
HEIGHT = CELL_SIZE * GRID_HEIGHT

# Barvy
BLACK = (0, 0, 0)
BLUE = (33, 33, 222)
YELLOW = (255, 255, 0)
WHITE = (255, 255, 255)
PINK = (255, 100, 180)
RED = (255, 0, 0)
CYAN = (0, 255, 255)
ORANGE = (255, 170, 0)

GHOST_COLORS = [RED, PINK, CYAN, ORANGE]

# Základní mapa (1 = zeď, 0 = kulička, 2 = prázdno)
LEVEL = [
    "1111111111111111111",
    "1000000000100000001",
    "1011111100101111101",
    "1020000000000000201",
    "1010111011101011101",
    "1000100000001000101",
    "1110101110111010111",
    "1000001000001000001",
    "1011101110111011101",
    "1000000000000000001",
    "1111111111111111111"
]
# Rozšíření mapy na 21 řádků
LEVEL = ["1"*19] + LEVEL + ["1"*19] + ["1"*19] + ["1"*19,]

def load_level():
    grid = []
    for y, line in enumerate(LEVEL):
        row = []
        for x, char in enumerate(line):
            if char == "1":
                row.append(1)
            elif char == "0":
                row.append(0)
            else:
                row.append(2)
        grid.append(row)
    return grid

def draw_maze(screen, grid):
    for y, row in enumerate(grid):
        for x, col in enumerate(row):
            rect = pygame.Rect(x * CELL_SIZE, y * CELL_SIZE, CELL_SIZE, CELL_SIZE)
            if col == 1:
                pygame.draw.rect(screen, BLUE, rect)
            elif col == 0:
                pygame.draw.circle(screen, WHITE, rect.center, 3)

def draw_pacman(screen, x, y, direction):
    center = (int(x * CELL_SIZE + CELL_SIZE//2), int(y * CELL_SIZE + CELL_SIZE//2))
    radius = CELL_SIZE//2-2
    mouth_open = 45
    angle = { "LEFT": 180, "RIGHT": 0, "UP": 90, "DOWN": 270 }[direction]
    pygame.draw.circle(screen, YELLOW, center, radius)
    pygame.draw.polygon(screen, BLACK, [
        center,
        (
            center[0] + int(radius * math.cos(math.radians(angle-mouth_open))),
            center[1] - int(radius * math.sin(math.radians(angle-mouth_open)))
        ),
        (
            center[0] + int(radius * math.cos(math.radians(angle+mouth_open))),
            center[1] - int(radius * math.sin(math.radians(angle+mouth_open)))
        ),
    ])

def draw_ghost(screen, x, y, color):
    rect = pygame.Rect(x * CELL_SIZE, y * CELL_SIZE, CELL_SIZE, CELL_SIZE)
    pygame.draw.ellipse(screen, color, rect)
    # Oči
    eye_radius = 3
    pygame.draw.circle(screen, WHITE, (rect.left + 6, rect.top + 7), eye_radius)
    pygame.draw.circle(screen, WHITE, (rect.left + CELL_SIZE - 6, rect.top + 7), eye_radius)
    pygame.draw.circle(screen, BLACK, (rect.left + 6, rect.top + 7), 1)
    pygame.draw.circle(screen, BLACK, (rect.left + CELL_SIZE - 6, rect.top + 7), 1)

class Pacman:
    def __init__(self, x, y):
        self.x, self.y = x, y
        self.direction = "LEFT"
        self.next_direction = "LEFT"

    def move(self, grid):
        dx, dy = {"LEFT":(-1,0), "RIGHT":(1,0), "UP":(0,-1), "DOWN":(0,1)}[self.next_direction]
        nx, ny = self.x + dx, self.y + dy
        if grid[ny][nx] != 1:
            self.direction = self.next_direction
        dx, dy = {"LEFT":(-1,0), "RIGHT":(1,0), "UP":(0,-1), "DOWN":(0,1)}[self.direction]
        nx, ny = self.x + dx, self.y + dy
        if grid[ny][nx] != 1:
            self.x, self.y = nx, ny

class Ghost:
    def __init__(self, x, y, color):
        self.x, self.y = x, y
        self.color = color
        self.direction = random.choice(["LEFT", "RIGHT", "UP", "DOWN"])

    def move(self, grid):
        directions = ["LEFT", "RIGHT", "UP", "DOWN"]
        random.shuffle(directions)
        for d in [self.direction] + directions:
            dx, dy = {"LEFT":(-1,0), "RIGHT":(1,0), "UP":(0,-1), "DOWN":(0,1)}[d]
            nx, ny = self.x + dx, self.y + dy
            if grid[ny][nx] != 1:
                self.x, self.y = nx, ny
                self.direction = d
                break

def main():
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Pacman v Pythonu")
    clock = pygame.time.Clock()
    grid = load_level()

    pacman = Pacman(9, 9)
    ghosts = [
        Ghost(9, 5, GHOST_COLORS[0]),
        Ghost(8, 6, GHOST_COLORS[1]),
        Ghost(10, 6, GHOST_COLORS[2]),
        Ghost(9, 7, GHOST_COLORS[3])
    ]

    score = 0

    running = True
    while running:
        screen.fill(BLACK)
        draw_maze(screen, grid)
        draw_pacman(screen, pacman.x, pacman.y, pacman.direction)
        for ghost in ghosts:
            draw_ghost(screen, ghost.x, ghost.y, ghost.color)

        # Score
        font = pygame.font.SysFont(None, 24)
        score_img = font.render(f"Skóre: {score}", True, WHITE)
        screen.blit(score_img, (5, HEIGHT-25))

        pygame.display.flip()
        clock.tick(8)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    pacman.next_direction = "LEFT"
                elif event.key == pygame.K_RIGHT:
                    pacman.next_direction = "RIGHT"
                elif event.key == pygame.K_UP:
                    pacman.next_direction = "UP"
                elif event.key == pygame.K_DOWN:
                    pacman.next_direction = "DOWN"

        pacman.move(grid)
        for ghost in ghosts:
            ghost.move(grid)
            if ghost.x == pacman.x and ghost.y == pacman.y:
                running = False  # Game Over

        # Snězení kuličky
        if grid[pacman.y][pacman.x] == 0:
            grid[pacman.y][pacman.x] = 2
            score += 10

        # Vyhrál?
        if all(col != 0 for row in grid for col in row):
            running = False

    # Konec hry
    screen.fill(BLACK)
    text = font.render("Konec hry!", True, YELLOW)
    screen.blit(text, (WIDTH//2 - 50, HEIGHT//2))
    pygame.display.flip()
    pygame.time.wait(2000)
    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()