import pygame
import sys
import random
import math

# Inicializace Pygame
pygame.init()

# Konstanty
WIDTH, HEIGHT = 800, 600
GRID_SIZE = 20
GRID_WIDTH = WIDTH // GRID_SIZE
GRID_HEIGHT = HEIGHT // GRID_SIZE
FPS = 10

# Barvy
BLACK = (0, 0, 0)
YELLOW = (255, 255, 0)
BLUE = (0, 0, 255)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
PINK = (255, 184, 255)
CYAN = (0, 255, 255)
ORANGE = (255, 184, 82)

# Vytvoření okna
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Pac-Man")
clock = pygame.time.Clock()

class PacMan:
    def __init__(self):
        self.x = GRID_WIDTH // 2
        self.y = GRID_HEIGHT // 2
        self.direction = (0, 0)
        self.next_direction = (0, 0)
        self.mouth_angle = 0
        self.mouth_opening = 5
        self.mouth_direction = 1
        
    def update(self):
        # Aktualizace směru, pokud je to možné
        new_x = self.x + self.next_direction[0]
        new_y = self.y + self.next_direction[1]
        if 0 <= new_x < GRID_WIDTH and 0 <= new_y < GRID_HEIGHT and maze[new_y][new_x] != 1:
            self.direction = self.next_direction
        
        # Pohyb
        new_x = self.x + self.direction[0]
        new_y = self.y + self.direction[1]
        if 0 <= new_x < GRID_WIDTH and 0 <= new_y < GRID_HEIGHT and maze[new_y][new_x] != 1:
            self.x = new_x
            self.y = new_y
            
        # Animace úst
        self.mouth_angle += self.mouth_direction * self.mouth_opening
        if self.mouth_angle > 45 or self.mouth_angle < 0:
            self.mouth_direction *= -1
            
        # Teleportace na druhou stranu
        if self.x < 0:
            self.x = GRID_WIDTH - 1
        elif self.x >= GRID_WIDTH:
            self.x = 0
            
    def draw(self):
        center_x = self.x * GRID_SIZE + GRID_SIZE // 2
        center_y = self.y * GRID_SIZE + GRID_SIZE // 2
        radius = GRID_SIZE // 2
        
        # Určení úhlu pro ústa podle směru
        if self.direction == (1, 0):  # vpravo
            start_angle = math.radians(self.mouth_angle)
            end_angle = math.radians(360 - self.mouth_angle)
        elif self.direction == (-1, 0):  # vlevo
            start_angle = math.radians(180 + self.mouth_angle)
            end_angle = math.radians(180 - self.mouth_angle)
        elif self.direction == (0, -1):  # nahoru
            start_angle = math.radians(90 + self.mouth_angle)
            end_angle = math.radians(90 - self.mouth_angle)
        elif self.direction == (0, 1):  # dolů
            start_angle = math.radians(270 + self.mouth_angle)
            end_angle = math.radians(270 - self.mouth_angle)
        else:  # žádný směr (začátek hry)
            start_angle = math.radians(self.mouth_angle)
            end_angle = math.radians(360 - self.mouth_angle)
        
        # Vykreslení Pac-Mana jako oblouku
        pygame.draw.arc(screen, YELLOW, 
                        (center_x - radius, center_y - radius, 
                         radius * 2, radius * 2),
                        start_angle, end_angle, radius)
        
        # Vykreslení kruhu pro zaokrouhlení
        pygame.draw.circle(screen, YELLOW, (center_x, center_y), radius)

class Ghost:
    def __init__(self, x, y, color):
        self.x = x
        self.y = y
        self.color = color
        self.direction = (0, 0)
        self.target = (0, 0)
        self.speed = 1
        self.eye_direction = (1, 0)
        
    def update(self, pacman):
        # Jednoduché AI - náhodný pohyb s tendencí k Pac-Manovi
        directions = [(1, 0), (-1, 0), (0, 1), (0, -1)]
        valid_directions = []
        
        for dx, dy in directions:
            new_x = self.x + dx
            new_y = self.y + dy
            if 0 <= new_x < GRID_WIDTH and 0 <= new_y < GRID_HEIGHT and maze[new_y][new_x] != 1:
                valid_directions.append((dx, dy))
        
        if valid_directions:
            # Někdy náhodně, někdy směrem k Pac-Manovi
            if random.random() < 0.7:
                # Směr k Pac-Manovi
                best_dir = None
                min_dist = float('inf')
                
                for dx, dy in valid_directions:
                    dist = abs(self.x + dx - pacman.x) + abs(self.y + dy - pacman.y)
                    if dist < min_dist:
                        min_dist = dist
                        best_dir = (dx, dy)
                
                self.direction = best_dir
            else:
                self.direction = random.choice(valid_directions)
            
            new_x = self.x + self.direction[0]
            new_y = self.y + self.direction[1]
            if 0 <= new_x < GRID_WIDTH and 0 <= new_y < GRID_HEIGHT and maze[new_y][new_x] != 1:
                self.x = new_x
                self.y = new_y
                
            self.eye_direction = self.direction
            
        # Teleportace na druhou stranu
        if self.x < 0:
            self.x = GRID_WIDTH - 1
        elif self.x >= GRID_WIDTH:
            self.x = 0
            
    def draw(self):
        center_x = self.x * GRID_SIZE + GRID_SIZE // 2
        center_y = self.y * GRID_SIZE + GRID_SIZE // 2
        radius = GRID_SIZE // 2
        
        # Tělo ducha
        pygame.draw.circle(screen, self.color, (center_x, center_y), radius)
        pygame.draw.rect(screen, self.color, 
                         (center_x - radius, center_y, radius * 2, radius))
        
        # Vlnité dno
        points = []
        for i in range(5):
            x = center_x - radius + i * radius // 2
            y = center_y + radius if i % 2 == 0 else center_y + radius - radius // 3
            points.append((x, y))
        points.append((center_x + radius, center_y + radius))
        pygame.draw.polygon(screen, self.color, points)
        
        # Oči
        eye_radius = radius // 3
        left_eye_x = center_x - radius // 3
        right_eye_x = center_x + radius // 3
        eye_y = center_y - radius // 4
        
        pygame.draw.circle(screen, WHITE, (left_eye_x, eye_y), eye_radius)
        pygame.draw.circle(screen, WHITE, (right_eye_x, eye_y), eye_radius)
        
        # Zorničky
        pupil_radius = eye_radius // 2
        dx, dy = self.eye_direction
        pygame.draw.circle(screen, BLUE, 
                          (left_eye_x + dx * pupil_radius, eye_y + dy * pupil_radius), 
                          pupil_radius)
        pygame.draw.circle(screen, BLUE, 
                          (right_eye_x + dx * pupil_radius, eye_y + dy * pupil_radius), 
                          pupil_radius)

def create_maze():
    # Jednoduché bludiště
    maze = [[0 for _ in range(GRID_WIDTH)] for _ in range(GRID_HEIGHT)]
    
    # Okraje
    for i in range(GRID_WIDTH):
        maze[0][i] = 1
        maze[GRID_HEIGHT-1][i] = 1
    for i in range(GRID_HEIGHT):
        maze[i][0] = 1
        maze[i][GRID_WIDTH-1] = 1
    
    # Některé vnitřní zdi
    for i in range(5, GRID_WIDTH-5):
        maze[5][i] = 1
        maze[GRID_HEIGHT-6][i] = 1
    
    for i in range(10, GRID_HEIGHT-10):
        maze[i][10] = 1
        maze[i][GRID_WIDTH-11] = 1
    
    # Některé tečky
    dots = []
    for y in range(1, GRID_HEIGHT-1):
        for x in range(1, GRID_WIDTH-1):
            if maze[y][x] == 0 and (x % 2 == 0 or y % 2 == 0):
                dots.append((x, y))
    
    return maze, dots

def draw_maze(maze, dots):
    for y in range(GRID_HEIGHT):
        for x in range(GRID_WIDTH):
            if maze[y][x] == 1:
                pygame.draw.rect(screen, BLUE, 
                                (x * GRID_SIZE, y * GRID_SIZE, GRID_SIZE, GRID_SIZE))
    
    for x, y in dots:
        pygame.draw.circle(screen, WHITE, 
                          (x * GRID_SIZE + GRID_SIZE // 2, y * GRID_SIZE + GRID_SIZE // 2), 
                          GRID_SIZE // 8)

# Hlavní funkce hry
def main():
    global maze
    
    maze, dots = create_maze()
    pacman = PacMan()
    ghosts = [
        Ghost(5, 5, RED),
        Ghost(GRID_WIDTH-5, 5, PINK),
        Ghost(5, GRID_HEIGHT-5, CYAN),
        Ghost(GRID_WIDTH-5, GRID_HEIGHT-5, ORANGE)
    ]
    
    score = 0
    game_over = False
    
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    pacman.next_direction = (0, -1)
                elif event.key == pygame.K_DOWN:
                    pacman.next_direction = (0, 1)
                elif event.key == pygame.K_LEFT:
                    pacman.next_direction = (-1, 0)
                elif event.key == pygame.K_RIGHT:
                    pacman.next_direction = (1, 0)
                elif event.key == pygame.K_r and game_over:
                    # Restart hry
                    maze, dots = create_maze()
                    pacman = PacMan()
                    ghosts = [
                        Ghost(5, 5, RED),
                        Ghost(GRID_WIDTH-5, 5, PINK),
                        Ghost(5, GRID_HEIGHT-5, CYAN),
                        Ghost(GRID_WIDTH-5, GRID_HEIGHT-5, ORANGE)
                    ]
                    score = 0
                    game_over = False
        
        if not game_over:
            # Aktualizace
            pacman.update()
            
            # Sbírání teček
            for dot in dots[:]:
                if pacman.x == dot[0] and pacman.y == dot[1]:
                    dots.remove(dot)
                    score += 10
            
            # Aktualizace duchů
            for ghost in ghosts:
                ghost.update(pacman)
                
                # Kolize s duchy
                if ghost.x == pacman.x and ghost.y == pacman.y:
                    game_over = True
        
        # Vykreslení
        screen.fill(BLACK)
        draw_maze(maze, dots)
        
        for ghost in ghosts:
            ghost.draw()
        pacman.draw()
        
        # Skóre
        font = pygame.font.SysFont(None, 36)
        score_text = font.render(f"Score: {score}", True, WHITE)
        screen.blit(score_text, (10, 10))
        
        if game_over:
            game_over_text = font.render("GAME OVER - Press R to restart", True, RED)
            screen.blit(game_over_text, 
                        (WIDTH // 2 - game_over_text.get_width() // 2, 
                         HEIGHT // 2 - game_over_text.get_height() // 2))
        
        pygame.display.flip()
        clock.tick(FPS)

if __name__ == "__main__":
    main()