import pygame
import random

# --- Nastavení hry ---
SIRKA, VYSKA = 600, 600
VELIKOST_POLICKA = 30
POCET_RADKU = VYSKA // VELIKOST_POLICKA
POCET_SLOUPCU = SIRKA // VELIKOST_POLICKA
FPS = 10

# --- Barvy ---
BILA = (255, 255, 255)
ZALTA = (255, 255, 0)
MODRA = (0, 0, 255)
CERNA = (0, 0, 0)
ORANZOVA = (255, 165, 0)
RUZOVA = (255, 192, 203)
ZELENA = (0, 255, 0)
CERVENA = (255, 0, 0)

# --- Mapa (1 = zeď, 0 = prázdné, 2 = jídlo) ---
MAPA = [
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    [1, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 1],
    [1, 2, 1, 1, 1, 2, 1, 1, 2, 1, 1, 2, 1, 1, 1, 2, 1, 1, 2, 1],
    [1, 2, 1, 1, 1, 2, 1, 1, 2, 1, 1, 2, 1, 1, 1, 2, 1, 1, 2, 1],
    [1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1],
    [1, 2, 1, 1, 1, 2, 1, 2, 1, 1, 1, 1, 1, 2, 1, 2, 1, 1, 2, 1],
    [1, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 1, 2, 1],
    [1, 1, 1, 1, 1, 2, 1, 1, 1, 0, 0, 1, 1, 1, 2, 1, 1, 1, 1, 1], # Duchové startují uprostřed
    [0, 0, 0, 0, 1, 2, 1, 0, 0, 0, 0, 0, 0, 1, 2, 1, 0, 0, 0, 0],
    [1, 1, 1, 1, 1, 2, 1, 0, 1, 1, 1, 1, 0, 1, 2, 1, 1, 1, 1, 1],
    [1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1],
    [1, 2, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 2, 1],
    [1, 2, 2, 2, 1, 2, 2, 2, 2, 1, 1, 2, 2, 2, 2, 2, 1, 2, 2, 1],
    [1, 1, 1, 2, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 1, 2, 1, 1],
    [1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
]

# --- Hráč Pac-Man ---
class Pacman:
    def __init__(self):
        self.x = 1 * VELIKOST_POLICKA
        self.y = 1 * VELIKOST_POLICKA
        self.smer_x = 0
        self.smer_y = 0
        self.skore = 0
        self.zivoty = 3

    def pohyb(self, dx, dy):
        nove_x = self.x + dx * VELIKOST_POLICKA
        nove_y = self.y + dy * VELIKOST_POLICKA

        # Kontrola kolize se zdí
        if 0 <= nove_x < SIRKA and 0 <= nove_y < VYSKA:
            radek = int(nove_y // VELIKOST_POLICKA)
            sloupec = int(nove_x // VELIKOST_POLICKA)
            if MAPA[radek][sloupec] != 1:  # 1 je zeď
                self.x = nove_x
                self.y = nove_y

    def aktualizuj(self):
        # Automatický pohyb Pac-Mana ve směru, kterým se aktuálně pohybuje
        radek = int(self.y // VELIKOST_POLICKA)
        sloupec = int(self.x // VELIKOST_POLICKA)

        nove_x_pokus = self.x + self.smer_x * VELIKOST_POLICKA
        nove_y_pokus = self.y + self.smer_y * VELIKOST_POLICKA

        if 0 <= nove_x_pokus < SIRKA and 0 <= nove_y_pokus < VYSKA:
            radek_pokus = int(nove_y_pokus // VELIKOST_POLICKA)
            sloupec_pokus = int(nove_x_pokus // VELIKOST_POLICKA)
            if MAPA[radek_pokus][sloupec_pokus] != 1:
                self.x = nove_x_pokus
                self.y = nove_y_pokus
            else:
                self.smer_x = 0
                self.smer_y = 0
        else:
            self.smer_x = 0
            self.smer_y = 0

        # Jídlo
        if MAPA[radek][sloupec] == 2:
            MAPA[radek][sloupec] = 0  # Snědeno
            self.skore += 10

    def vykresli(self, screen):
        pygame.draw.circle(screen, ZALTA, (int(self.x + VELIKOST_POLICKA / 2), int(self.y + VELIKOST_POLICKA / 2)), int(VELIKOST_POLICKA / 2) - 2)

# --- Duchové ---
class Duch:
    def __init__(self, x, y, barva):
        self.x = x * VELIKOST_POLICKA
        self.y = y * VELIKOST_POLICKA
        self.barva = barva
        self.smer_x = 0
        self.smer_y = 0
        self.puvodni_x = x * VELIKOST_POLICKA
        self.puvodni_y = y * VELIKOST_POLICKA

    def pohyb(self):
        mozne_smery = []
        aktualni_radek = int(self.y // VELIKOST_POLICKA)
        aktualni_sloupec = int(self.x // VELIKOST_POLICKA)

        # Kontrola všech čtyř směrů
        smery = [(0, 1), (0, -1), (1, 0), (-1, 0)] # dolu, nahoru, doprava, doleva

        for dx, dy in smery:
            nove_radek = aktualni_radek + dy
            nove_sloupec = aktualni_sloupec + dx

            if 0 <= nove_radek < POCET_RADKU and 0 <= nove_sloupec < POCET_SLOUPCU:
                if MAPA[nove_radek][nove_sloupec] != 1: # Není zeď
                    mozne_smery.append((dx, dy))

        if mozne_smery:
            self.smer_x, self.smer_y = random.choice(mozne_smery)

        nove_x = self.x + self.smer_x * VELIKOST_POLICKA
        nove_y = self.y + self.smer_y * VELIKOST_POLICKA

        # Kontrola kolize se zdí před skutečným pohybem
        if 0 <= nove_x < SIRKA and 0 <= nove_y < VYSKA:
            radek_cil = int(nove_y // VELIKOST_POLICKA)
            sloupec_cil = int(nove_x // VELIKOST_POLICKA)
            if MAPA[radek_cil][sloupec_cil] != 1:
                self.x = nove_x
                self.y = nove_y
        else:
            # Pokud narazí na okraj mapy, vyber nový směr
            self.smer_x = 0
            self.smer_y = 0


    def vykresli(self, screen):
        pygame.draw.circle(screen, self.barva, (int(self.x + VELIKOST_POLICKA / 2), int(self.y + VELIKOST_POLICKA / 2)), int(VELIKOST_POLICKA / 2) - 2)
        # Oči duchů (jednoduché bílé kruhy s černými zorničkami)
        pygame.draw.circle(screen, BILA, (int(self.x + VELIKOST_POLICKA / 2 - VELIKOST_POLICKA / 6), int(self.y + VELIKOST_POLICKA / 3)), int(VELIKOST_POLICKA / 8))
        pygame.draw.circle(screen, BILA, (int(self.x + VELIKOST_POLICKA / 2 + VELIKOST_POLICKA / 6), int(self.y + VELIKOST_POLICKA / 3)), int(VELIKOST_POLICKA / 8))
        pygame.draw.circle(screen, CERNA, (int(self.x + VELIKOST_POLICKA / 2 - VELIKOST_POLICKA / 6), int(self.y + VELIKOST_POLICKA / 3)), int(VELIKOST_POLICKA / 16))
        pygame.draw.circle(screen, CERNA, (int(self.x + VELIKOST_POLICKA / 2 + VELIKOST_POLICKA / 6), int(self.y + VELIKOST_POLICKA / 3)), int(VELIKOST_POLICKA / 16))


# --- Inicializace Pygame ---
pygame.init()
screen = pygame.display.set_mode((SIRKA, VYSKA))
pygame.display.set_caption("Pac-Man")
hodiny = pygame.time.Clock()
font = pygame.font.Font(None, 36)

pacman = Pacman()
duchove = [
    Duch(9, 7, ORANZOVA), # Pozice 9,7 je uprostřed 'domu' duchů
    Duch(10, 7, RUZOVA),
    Duch(9, 8, ZELENA),
    Duch(10, 8, CERVENA)
]

# --- Herní smyčka ---
bezi = True
while bezi:
    for udalost in pygame.event.get():
        if udalost.type == pygame.QUIT:
            bezi = False
        if udalost.type == pygame.KEYDOWN:
            if udalost.key == pygame.K_LEFT:
                pacman.smer_x = -1
                pacman.smer_y = 0
            if udalost.key == pygame.K_RIGHT:
                pacman.smer_x = 1
                pacman.smer_y = 0
            if udalost.key == pygame.K_UP:
                pacman.smer_x = 0
                pacman.smer_y = -1
            if udalost.key == pygame.K_DOWN:
                pacman.smer_x = 0
                pacman.smer_y = 1

    # --- Aktualizace ---
    pacman.aktualizuj()
    for duch in duchove:
        duch.pohyb()

    # Kontrola kolize Pac-Mana s duchy
    for duch in duchove:
        if (pacman.x < duch.x + VELIKOST_POLICKA and
            pacman.x + VELIKOST_POLICKA > duch.x and
            pacman.y < duch.y + VELIKOST_POLICKA and
            pacman.y + VELIKOST_POLICKA > duch.y):
            pacman.zivoty -= 1
            pacman.x = 1 * VELIKOST_POLICKA  # Reset Pac-Mana
            pacman.y = 1 * VELIKOST_POLICKA
            for d in duchove: # Reset duchů
                d.x = d.puvodni_x
                d.y = d.puvodni_y

            if pacman.zivoty == 0:
                bezi = False # Konec hry

    # --- Vykreslení ---
    screen.fill(CERNA) # Vyčistí obrazovku

    # Vykreslení mapy
    for radek_idx, radek in enumerate(MAPA):
        for sloupec_idx, hodnota in enumerate(radek):
            if hodnota == 1: # Zeď
                pygame.draw.rect(screen, MODRA, (sloupec_idx * VELIKOST_POLICKA, radek_idx * VELIKOST_POLICKA, VELIKOST_POLICKA, VELIKOST_POLICKA))
            elif hodnota == 2: # Jídlo
                pygame.draw.circle(screen, BILA, (sloupec_idx * VELIKOST_POLICKA + VELIKOST_POLICKA // 2, radek_idx * VELIKOST_POLICKA + VELIKOST_POLICKA // 2), VELIKOST_POLICKA // 8)

    pacman.vykresli(screen)
    for duch in duchove:
        duch.vykresli(screen)

    # Zobrazení skóre a životů
    text_skore = font.render(f"Skóre: {pacman.skore}", True, BILA)
    screen.blit(text_skore, (5, 5))
    text_zivoty = font.render(f"Životy: {pacman.zivoty}", True, BILA)
    screen.blit(text_zivoty, (SIRKA - text_zivoty.get_width() - 5, 5))

    pygame.display.flip() # Aktualizuje celou obrazovku
    hodiny.tick(FPS) # Omezí FPS

pygame.quit()