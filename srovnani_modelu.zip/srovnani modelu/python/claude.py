import pygame
import random
import math

# Inicializace pygame
pygame.init()

# Konstanty
WINDOW_WIDTH = 800
WINDOW_HEIGHT = 600
FPS = 60

# Barvy
BLACK = (0, 0, 0)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
PINK = (255, 192, 203)
CYAN = (0, 255, 255)
ORANGE = (255, 165, 0)

# Velikosti
CELL_SIZE = 25
PACMAN_SIZE = 20
GHOST_SIZE = 18
DOT_SIZE = 3
POWER_PELLET_SIZE = 8

class PacMan:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.direction = 0  # 0=právo, 1=dolů, 2=vlevo, 3=nahoru
        self.next_direction = 0
        self.speed = 2
        self.mouth_open = True
        self.mouth_timer = 0
        
    def update(self, maze):
        # Animace úst
        self.mouth_timer += 1
        if self.mouth_timer >= 10:
            self.mouth_open = not self.mouth_open
            self.mouth_timer = 0
        
        # Směr pohybu
        dx, dy = 0, 0
        if self.direction == 0:    # vpravo
            dx = self.speed
        elif self.direction == 1:  # dolů
            dy = self.speed
        elif self.direction == 2:  # vlevo
            dx = -self.speed
        elif self.direction == 3:  # nahoru
            dy = -self.speed
        
        # Kontrola kolize
        new_x = self.x + dx
        new_y = self.y + dy
        
        if not self.check_wall_collision(new_x, new_y, maze):
            self.x = new_x
            self.y = new_y
        
        # Teleport přes okraje
        if self.x < 0:
            self.x = WINDOW_WIDTH - PACMAN_SIZE
        elif self.x > WINDOW_WIDTH:
            self.x = 0
    
    def check_wall_collision(self, x, y, maze):
        # Jednoduchá kontrola kolize se zdmi
        margin = PACMAN_SIZE // 2
        grid_x1 = max(0, (x - margin) // CELL_SIZE)
        grid_x2 = min(len(maze[0]) - 1, (x + margin) // CELL_SIZE)
        grid_y1 = max(0, (y - margin) // CELL_SIZE)
        grid_y2 = min(len(maze) - 1, (y + margin) // CELL_SIZE)
        
        for gy in range(int(grid_y1), int(grid_y2) + 1):
            for gx in range(int(grid_x1), int(grid_x2) + 1):
                if maze[gy][gx] == 1:  # zeď
                    return True
        return False
    
    def set_direction(self, direction):
        self.next_direction = direction
        # Okamžitá změna směru pokud není zeď
        self.direction = direction
    
    def draw(self, screen):
        # Kreslení Pac-Mana
        center_x = int(self.x + PACMAN_SIZE // 2)
        center_y = int(self.y + PACMAN_SIZE // 2)
        radius = PACMAN_SIZE // 2
        
        if self.mouth_open:
            # Pac-Man s otevřenými ústy
            start_angle = self.direction * 90 + 30
            end_angle = self.direction * 90 - 30
            
            pygame.draw.circle(screen, YELLOW, (center_x, center_y), radius)
            
            # Ústa (trojúhelník)
            mouth_points = [
                (center_x, center_y),
                (center_x + radius * math.cos(math.radians(start_angle)),
                 center_y + radius * math.sin(math.radians(start_angle))),
                (center_x + radius * math.cos(math.radians(end_angle)),
                 center_y + radius * math.sin(math.radians(end_angle)))
            ]
            pygame.draw.polygon(screen, BLACK, mouth_points)
        else:
            # Zavřená ústa
            pygame.draw.circle(screen, YELLOW, (center_x, center_y), radius)
        
        # Oko
        eye_x = center_x + 3 * math.cos(math.radians(self.direction * 90 + 90))
        eye_y = center_y + 3 * math.sin(math.radians(self.direction * 90 + 90))
        pygame.draw.circle(screen, BLACK, (int(eye_x), int(eye_y)), 2)

class Ghost:
    def __init__(self, x, y, color):
        self.x = x
        self.y = y
        self.color = color
        self.direction = random.randint(0, 3)
        self.speed = 1
        self.scared = False
        self.scared_timer = 0
        
    def update(self, maze, pacman):
        if self.scared:
            self.scared_timer -= 1
            if self.scared_timer <= 0:
                self.scared = False
        
        # Jednoduchá AI - náhodný pohyb s mírnou preferencí směřovat k Pac-Manovi
        if random.randint(0, 30) == 0:  # Změna směru
            if random.randint(0, 2) == 0:  # Náhodný směr
                self.direction = random.randint(0, 3)
            else:  # Směr k Pac-Manovi
                if abs(pacman.x - self.x) > abs(pacman.y - self.y):
                    self.direction = 0 if pacman.x > self.x else 2
                else:
                    self.direction = 1 if pacman.y > self.y else 3
        
        # Pohyb
        dx, dy = 0, 0
        if self.direction == 0:    dx = self.speed
        elif self.direction == 1:  dy = self.speed
        elif self.direction == 2:  dx = -self.speed
        elif self.direction == 3:  dy = -self.speed
        
        new_x = self.x + dx
        new_y = self.y + dy
        
        if not self.check_wall_collision(new_x, new_y, maze):
            self.x = new_x
            self.y = new_y
        else:
            self.direction = random.randint(0, 3)
        
        # Teleport přes okraje
        if self.x < 0:
            self.x = WINDOW_WIDTH - GHOST_SIZE
        elif self.x > WINDOW_WIDTH:
            self.x = 0
    
    def check_wall_collision(self, x, y, maze):
        margin = GHOST_SIZE // 2
        grid_x1 = max(0, (x - margin) // CELL_SIZE)
        grid_x2 = min(len(maze[0]) - 1, (x + margin) // CELL_SIZE)
        grid_y1 = max(0, (y - margin) // CELL_SIZE)
        grid_y2 = min(len(maze) - 1, (y + margin) // CELL_SIZE)
        
        for gy in range(int(grid_y1), int(grid_y2) + 1):
            for gx in range(int(grid_x1), int(grid_x2) + 1):
                if maze[gy][gx] == 1:
                    return True
        return False
    
    def make_scared(self):
        self.scared = True
        self.scared_timer = 300  # 5 sekund při 60 FPS
    
    def draw(self, screen):
        center_x = int(self.x + GHOST_SIZE // 2)
        center_y = int(self.y + GHOST_SIZE // 2)
        radius = GHOST_SIZE // 2
        
        color = BLUE if self.scared else self.color
        
        # Tělo ducha (kruh + obdélník)
        pygame.draw.circle(screen, color, (center_x, center_y - 2), radius)
        pygame.draw.rect(screen, color, 
                        (center_x - radius, center_y - 2, 
                         radius * 2, radius + 2))
        
        # Vlnitý spodek
        for i in range(4):
            x = center_x - radius + i * (radius // 2)
            pygame.draw.polygon(screen, color, 
                              [(x, center_y + radius), 
                               (x + radius//4, center_y + radius//2),
                               (x + radius//2, center_y + radius)])
        
        # Oči
        if not self.scared:
            pygame.draw.circle(screen, WHITE, (center_x - 4, center_y - 4), 3)
            pygame.draw.circle(screen, WHITE, (center_x + 4, center_y - 4), 3)
            pygame.draw.circle(screen, BLACK, (center_x - 4, center_y - 4), 1)
            pygame.draw.circle(screen, BLACK, (center_x + 4, center_y - 4), 1)
        else:
            # Vystrašené oči
            pygame.draw.circle(screen, WHITE, (center_x - 4, center_y - 2), 2)
            pygame.draw.circle(screen, WHITE, (center_x + 4, center_y - 2), 2)

class Game:
    def __init__(self):
        self.screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
        pygame.display.set_caption("Pac-Man")
        self.clock = pygame.time.Clock()
        
        # Vytvoření bludiště
        self.maze = self.create_maze()
        self.dots = self.create_dots()
        self.power_pellets = [(50, 50), (WINDOW_WIDTH-75, 50), 
                             (50, WINDOW_HEIGHT-75), (WINDOW_WIDTH-75, WINDOW_HEIGHT-75)]
        
        # Hráči
        self.pacman = PacMan(400, 300)
        self.ghosts = [
            Ghost(350, 250, RED),
            Ghost(450, 250, PINK),
            Ghost(350, 350, CYAN),
            Ghost(450, 350, ORANGE)
        ]
        
        self.score = 0
        self.lives = 3
        self.font = pygame.font.Font(None, 36)
        
    def create_maze(self):
        # Jednoduchý grid pro bludiště
        rows = WINDOW_HEIGHT // CELL_SIZE
        cols = WINDOW_WIDTH // CELL_SIZE
        
        maze = [[0 for _ in range(cols)] for _ in range(rows)]
        
        # Okraje
        for i in range(cols):
            maze[0][i] = 1
            maze[rows-1][i] = 1
        for i in range(rows):
            maze[i][0] = 1
            maze[i][cols-1] = 1
            
        # Nějaké vnitřní zdi
        for i in range(2, rows-2, 4):
            for j in range(2, cols-2, 6):
                if random.randint(0, 3) != 0:
                    maze[i][j] = 1
                    if j+1 < cols-1:
                        maze[i][j+1] = 1
                    if i+1 < rows-1:
                        maze[i+1][j] = 1
        
        return maze
    
    def create_dots(self):
        dots = []
        for y in range(1, len(self.maze)-1):
            for x in range(1, len(self.maze[0])-1):
                if self.maze[y][x] == 0:
                    if random.randint(0, 2) == 0:  # Ne všude
                        dots.append((x * CELL_SIZE + CELL_SIZE//2, 
                                   y * CELL_SIZE + CELL_SIZE//2))
        return dots
    
    def check_dot_collision(self):
        pacman_center = (self.pacman.x + PACMAN_SIZE//2, 
                        self.pacman.y + PACMAN_SIZE//2)
        
        for dot in self.dots[:]:
            distance = math.sqrt((pacman_center[0] - dot[0])**2 + 
                               (pacman_center[1] - dot[1])**2)
            if distance < PACMAN_SIZE//2 + DOT_SIZE:
                self.dots.remove(dot)
                self.score += 10
    
    def check_power_pellet_collision(self):
        pacman_center = (self.pacman.x + PACMAN_SIZE//2, 
                        self.pacman.y + PACMAN_SIZE//2)
        
        for pellet in self.power_pellets[:]:
            distance = math.sqrt((pacman_center[0] - pellet[0])**2 + 
                               (pacman_center[1] - pellet[1])**2)
            if distance < PACMAN_SIZE//2 + POWER_PELLET_SIZE:
                self.power_pellets.remove(pellet)
                self.score += 50
                for ghost in self.ghosts:
                    ghost.make_scared()
    
    def check_ghost_collision(self):
        pacman_center = (self.pacman.x + PACMAN_SIZE//2, 
                        self.pacman.y + PACMAN_SIZE//2)
        
        for ghost in self.ghosts:
            ghost_center = (ghost.x + GHOST_SIZE//2, 
                           ghost.y + GHOST_SIZE//2)
            distance = math.sqrt((pacman_center[0] - ghost_center[0])**2 + 
                               (pacman_center[1] - ghost_center[1])**2)
            
            if distance < PACMAN_SIZE//2 + GHOST_SIZE//2:
                if ghost.scared:
                    self.score += 200
                    # Reset ghost position
                    ghost.x = 400
                    ghost.y = 250
                    ghost.scared = False
                else:
                    self.lives -= 1
                    if self.lives > 0:
                        # Reset positions
                        self.pacman.x = 400
                        self.pacman.y = 300
                        for g in self.ghosts:
                            g.x = 350 + (self.ghosts.index(g) % 2) * 100
                            g.y = 250 + (self.ghosts.index(g) // 2) * 100
                    return True
        return False
    
    def handle_input(self):
        keys = pygame.key.get_pressed()
        if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
            self.pacman.set_direction(0)
        elif keys[pygame.K_DOWN] or keys[pygame.K_s]:
            self.pacman.set_direction(1)
        elif keys[pygame.K_LEFT] or keys[pygame.K_a]:
            self.pacman.set_direction(2)
        elif keys[pygame.K_UP] or keys[pygame.K_w]:
            self.pacman.set_direction(3)
    
    def draw_maze(self):
        for y in range(len(self.maze)):
            for x in range(len(self.maze[0])):
                if self.maze[y][x] == 1:
                    pygame.draw.rect(self.screen, BLUE,
                                   (x * CELL_SIZE, y * CELL_SIZE,
                                    CELL_SIZE, CELL_SIZE))
    
    def draw_dots(self):
        for dot in self.dots:
            pygame.draw.circle(self.screen, WHITE, dot, DOT_SIZE)
    
    def draw_power_pellets(self):
        for pellet in self.power_pellets:
            pygame.draw.circle(self.screen, WHITE, pellet, POWER_PELLET_SIZE)
    
    def draw_ui(self):
        score_text = self.font.render(f"Skóre: {self.score}", True, WHITE)
        lives_text = self.font.render(f"Životy: {self.lives}", True, WHITE)
        
        self.screen.blit(score_text, (10, 10))
        self.screen.blit(lives_text, (10, 50))
        
        if self.lives <= 0:
            game_over_text = self.font.render("KONEC HRY! Stiskni R pro restart", True, RED)
            text_rect = game_over_text.get_rect(center=(WINDOW_WIDTH//2, WINDOW_HEIGHT//2))
            self.screen.blit(game_over_text, text_rect)
        
        if len(self.dots) == 0:
            win_text = self.font.render("VÝHRA! Stiskni R pro restart", True, YELLOW)
            text_rect = win_text.get_rect(center=(WINDOW_WIDTH//2, WINDOW_HEIGHT//2))
            self.screen.blit(win_text, text_rect)
    
    def restart(self):
        self.__init__()
    
    def run(self):
        running = True
        
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_r and (self.lives <= 0 or len(self.dots) == 0):
                        self.restart()
            
            if self.lives > 0 and len(self.dots) > 0:
                self.handle_input()
                
                # Update
                self.pacman.update(self.maze)
                for ghost in self.ghosts:
                    ghost.update(self.maze, self.pacman)
                
                # Kolize
                self.check_dot_collision()
                self.check_power_pellet_collision()
                self.check_ghost_collision()
            
            # Kreslení
            self.screen.fill(BLACK)
            self.draw_maze()
            self.draw_dots()
            self.draw_power_pellets()
            self.pacman.draw(self.screen)
            for ghost in self.ghosts:
                ghost.draw(self.screen)
            self.draw_ui()
            
            pygame.display.flip()
            self.clock.tick(FPS)
        
        pygame.quit()

if __name__ == "__main__":
    game = Game()
    game.run()